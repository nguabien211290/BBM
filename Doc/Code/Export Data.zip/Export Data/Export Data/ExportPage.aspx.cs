﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Expost_Data
{
    public partial class ExportPage : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
        }
        private DataTable GetData()
        {
            // Here we create a DataTable with four columns.
            DataTable dtSample = new DataTable();
            dtSample.Columns.Add("Dosage", typeof(int));
            dtSample.Columns.Add("Drug", typeof(string));
            dtSample.Columns.Add("Patient", typeof(string));
            dtSample.Columns.Add("Date", typeof(DateTime));

            // Here we add five DataRows.
            dtSample.Rows.Add(25, "Indocin", "David", DateTime.Now);
            dtSample.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
            dtSample.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
            dtSample.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            dtSample.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
            dtSample.Rows.Add(25, "Indocin", "David", DateTime.Now);
            dtSample.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
            dtSample.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
            dtSample.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            dtSample.Rows.Add(25, "Indocin", "David", DateTime.Now);
            dtSample.Rows.Add(50, "Enebrel", "Sam", DateTime.Now);
            dtSample.Rows.Add(10, "Hydralazine", "Christoff", DateTime.Now);
            dtSample.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            dtSample.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
            dtSample.Rows.Add(25, "Indocin", "David", DateTime.Now);
            
            return dtSample;

        }
        protected void ExportToWord(object sender, EventArgs e)
        {
            DataTable dt = GetData();

            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dt;
            GridView1.DataBind();

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=MyReport.doc");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-word ";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            GridView1.RenderControl(hw);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }
       
        protected void ExportToExcel(object sender, EventArgs e)
        {
            //Get the data we want to export.
            DataTable dt = GetData();

            //Create a dummy GridView and Bind the data source we have.
            GridView grdExportData = new GridView();

            grdExportData.AllowPaging = false;
            grdExportData.DataSource = dt;
            grdExportData.DataBind();

            //Clear the response and add the content types and headers to it.
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=MyReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";

            //We need this string writer and HTML writer in order to render the grid inside it.
            StringWriter swExportData = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(swExportData);

            //Lets render the Grid inside the HtmlWriter and then automatically we will have it converted into eauivalent string.
            grdExportData.RenderControl(hw);

            //Write the response now and you will get your excel sheet as download file
            Response.Output.Write(swExportData.ToString());
            Response.Flush();
            Response.End();
        }

        protected void ExportToPDF(object sender, EventArgs e)
        {
            DataTable dt = GetData();

            //Create a dummy GridView
            GridView GridView1 = new GridView();
            GridView1.AllowPaging = false;
            GridView1.DataSource = dt;
            GridView1.DataBind();

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=MyReport.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            GridView1.RenderControl(hw);
            StringReader sr = new StringReader(sw.ToString());
            Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
            pdfDoc.Open();
            htmlparser.Parse(sr);
            pdfDoc.Close();
            Response.Write(pdfDoc);
            Response.End();
        }

        protected void ExportToCSV(object sender, EventArgs e)
        {
            DataTable dt = GetData();

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=MyReport.csv");
            Response.Charset = "";
            Response.ContentType = "application/text";


            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < dt.Columns.Count; k++)
            {
                //add separator
                sb.Append(dt.Columns[k].ColumnName + ',');
            }
            //append new line
            sb.Append("\r\n");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int k = 0; k < dt.Columns.Count; k++)
                {
                    //add separator
                    sb.Append(dt.Rows[i][k].ToString().Replace(",", ";") + ',');
                }
                //append new line
                sb.Append("\r\n");
            }
            Response.Output.Write(sb.ToString());
            Response.Flush();
            Response.End();
        }

        private void ExportToExcelSheet()
        {
            //Get the data we want to export.
            DataTable dt = GetData();

            //Create a dummy GridView and Bind the data source we have.
            GridView grdExportData = new GridView();

            grdExportData.AllowPaging = false;
            grdExportData.DataSource = dt;
            grdExportData.DataBind();

            //Clear the response and add the content types and headers to it.
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=MyReport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";

            //We need this string writer and HTML writer in order to render the grid inside it.
            StringWriter swExportData = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(swExportData);

            //Lets render the Grid inside the HtmlWriter and then automatically we will have it converted into eauivalent string.
            grdExportData.RenderControl(hw);

            //Write the response now and you will get your excel sheet as download file
            Response.Output.Write(swExportData.ToString());
            Response.Flush();
            Response.End();
        }
    }
}