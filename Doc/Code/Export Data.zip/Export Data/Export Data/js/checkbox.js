
$(document).ready(function ($) {
            $(".clickableRow").click(function () {
                var alertData = $(this).attr("data");
                alert(alertData);
            });
            $(".clickableRow").tooltip();


            $("#showAlert").on("close.bs.alert", function () {
                $(this).hide();
                return false;
            });

            $("#showAlertRadio").on("close.bs.alert", function () {
                $(this).hide();
                return false;
            });
        });

        $('.checkbox').click(function (e) {
            var text = $(this).val();
            if (text.toLowerCase().indexOf("radio") >= 0) {
                $("#pAlertRadio").text(text);
                $("#showAlertRadio").show();
            }
            else {
                $("#pAlert").text(text);
                $("#showAlert").show();
            }


        });