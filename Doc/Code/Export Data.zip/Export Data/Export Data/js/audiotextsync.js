// ensure the web page (DOM) has loaded
        document.addEventListener("DOMContentLoaded", function () {

            var pop = Popcorn("#greeting");

            var wordTimes = {
                "w1": { start: 1, end: 1.4 },
                "w2": { start: 1.6, end: 1.9 },
                "w3": { start: 1.9, end: 2.5 },
                "w4": { start: 2.5, end: 2.8 },
                "w5": { start: 2.8, end: 3.2 },
                "w6": { start: 3.2, end: 3.6 },
                "w7": { start: 3.9, end: 4.5 },
                "w8": { start: 4.5, end: 4.8 },
                "w9": { start: 4.8, end: 5.3 },
                "w10": { start: 5.3, end: 5.7 },
                "w11": { start: 5.7, end: 6.0 },
                "w12": { start: 6.0, end: 6.5 }
            };

            $.each(wordTimes, function (id, time) {
                pop.footnote({
                    start: time.start,
                    end: time.end,
                    text: '',
                    target: id,
                    effect: "applyclass",
                    applyclass: "selected"
                });
            });

            pop.play();

            $('.word').click(function () {
                var audio = $('#greeting');
                audio[0].currentTime = parseFloat($(this).data('start'), 10);
                audio[0].play();
            });

        }, false);