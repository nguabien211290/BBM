$(document).ready(function () {
            LoadPage("Page1.html");
        });

        function LoadPage(pageName) {
            $("#pageContainer").load(pageName);
            SetActiveTab(pageName);
        }

        function SetActiveTab(pageName) {

            switch (pageName) {
                case 'Page1.html':
                    $(".nav").removeClass("active");
                    $(".nav1").addClass("active");
                    break;
                case 'Page2.html':
                    $(".nav").removeClass("active");
                    $(".nav2").addClass("active");
                    break;
                case 'Page3.html':
                    $(".nav").removeClass("active");
                    $(".nav3").addClass("active");
                    break;
                case 'Page4.html':
                    $(".nav").removeClass("active");
                    $(".nav4").addClass("active");
                    break;
                case 'Page5.html':
                    $(".nav").removeClass("active");
                    $(".nav5").addClass("active");
                    break;
                default:
                    $(".nav").removeClass("active");
                    $(".nav1").addClass("active");
                    break;
            }
        }

